 function f = sigf(t)

 sigma = 0.8;
 f = exp(-t.^2/ (2*sigma^2));
 