function [value, x0n] = image_cor (input, sense, diff_image, insertion_point, tip_point )

%radius, arc_length
radius = input(1);
arc_length = input(2);

%insertion_point = ginput(1)
%%
%radius = 1600;
%arc_length = 200;
%sense = 1;
blank_image = diff_image * 0;

% gen_image = create_needle_image(...
%     insertion_point, radius, arc_length, sense,...
%     blank_image);
[gen_image, x0n] = create_needle_image_2(...
    insertion_point, radius, arc_length, sense,...
    blank_image,tip_point);

ker = fspecial('disk', 1);
gen_image = (conv2(gen_image, ker, 'same') > 0);


cor_image = gen_image .* diff_image;
% 
% figure(5)
% imshow(2*cor_image .* diff_image,[])
% pause(0.1);

[row, col, v] = find(gen_image == 1);

%value = sum(sum(cor_image)) / (arc_length*);

value = sum(sum(cor_image)) / (size(row,1));

value = - value;