function output = gpD (n)

output = gD(n+1/2) - gD(n - 1/2);