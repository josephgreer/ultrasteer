function [leftCenters, rightCenters,leftImgNeedle_center,rightImgNeedle_center] = centerSegmentation(leftImg,rightImg,leftBack,rightBack)
       

 %   [rpix_points,lpix_points] = select_three_points(rightImg,leftImg);
 %   leftMask = create_circular_mask (leftImg,leftBack, lpix_points);
 %   rightMask = create_circular_mask (rightImg,rightBack, rpix_points);

    % SCALE PIXELS!
    leftImg = scalePixels(leftImg, ones(size(leftImg)));
    leftBack = scalePixels(leftBack, ones(size(leftBack))); %Scale the pixel values
    rightImg = scalePixels(rightImg, ones(size(rightImg)));
    rightBack= scalePixels(rightBack, ones(size(rightBack))); %Scale the pixel values

    [leftNeedle_Mask, leftBackground_masked, leftGel_Mask, leftThresh, leftROI, leftGelMotion] = imageInfo (leftImg, leftBack);
    [rightNeedle_Mask, rightBackground_masked, rightGel_Mask, rightThresh, rightROI, rightGelMotion ] = imageInfo (rightImg, rightBack);
    
    
    % Create motion images
    leftImgMotion = leftBack- leftImg; %see prep_images and segmentNeedle2.m
    rightImgMotion = rightBack- rightImg; 
    
    se = strel('disk',2);
    leftImgMotion_tophat = imtophat(leftImgMotion.*leftNeedle_Mask,se);
    rightImgMotion_tophat = imtophat(rightImgMotion.*rightNeedle_Mask,se);
   
     
  %  figure; imshow(leftImgMotion_tophat);
  %  figure; imshow(rightImgMotion_tophat);
    
%     % Scale the motion image to be from 0 to 1
%     [leftImgMotion, max_val_left, min_val_left] = scalePixels(leftImgMotion.*leftNeedle_Mask ,leftNeedle_Mask);
%     [rightImgMotion, max_val_right, min_val_right] = scalePixels(rightImgMotion.*rightNeedle_Mask ,rightNeedle_Mask);

    %imshow(cam(n).img_motion,[]);
        
    %Determine the gel motion
    %leftGelMotion = (leftBack- leftImg).*leftGel_Mask;
    %leftGelMotion = scalePixels(leftGelMotion,leftGel_Mask, max_val_left, min_val_left);
   
    %figure; imshow(leftImgMotion);
    %figure; imshow(rightImgMotion);
    
    leftImgNeedle = imadjust(leftImgMotion_tophat,[0; 0.1],[]);
    rightImgNeedle = imadjust(rightImgMotion_tophat,[0;0.1],[]);
    
    %figure; imshow(leftImgNeedle);
    %figure; imshow(rightImgNeedle);
        
    %Determine the gel motion
    %rightGelMotion = (rightBack- rightImg).*rightGel_Mask;
    %rightGelMotion = scalePixels(rightGelMotion,rightGel_Mask,
    %max_val_right, min_val_right);
     
    leftImgNeedle_bw = im2bw(leftImgNeedle,0.5);
    rightImgNeedle_bw = im2bw(rightImgNeedle,0.5);
    
    %figure; imshow(leftImgNeedle_bw);
    %figure; imshow(rightImgNeedle_bw);


    leftImgNeedle_center = bwmorph(leftImgNeedle_bw,'spur');
    rightImgNeedle_center = bwmorph(rightImgNeedle_bw,'spur');
    leftImgNeedle_center = bwmorph(leftImgNeedle_center,'majority');
    rightImgNeedle_center = bwmorph(rightImgNeedle_center,'majority');
    leftImgNeedle_center = bwmorph(leftImgNeedle_center,'clean');
    rightImgNeedle_center = bwmorph(rightImgNeedle_center,'clean');

   
    %figure; imshow(leftImgNeedle_center);
    %figure; imshow(rightImgNeedle_center);
     
  
    leftImgNeedle_connected = connectedComponents(leftImgNeedle_center);
    rightImgNeedle_connected = connectedComponents(rightImgNeedle_center);
    
    
   % figure; imshow(leftImgNeedle_connected);
   % figure; imshow(rightImgNeedle_connected);
    
    leftImgNeedle_connected = bwmorph(leftImgNeedle_connected,'thin');
    rightImgNeedle_connected = bwmorph(rightImgNeedle_connected,'thin');
  
   
    %figure; imshow(leftImgNeedle_connected);
    %figure; imshow(rightImgNeedle_connected);
    
 %  leftImgNeedle_improved = needle_points2 (leftImgMotion, 2, 0.8, 'true', leftNeedle_Mask, leftImgNeedle);         % SEE HOW THIS WORKS.... DOESNT" CHANGE ANYTHING!
 %  rightImgNeedle_improved = needle_points2 (rightImgMotion, 2, 0.8,'true', rightNeedle_Mask, rightImgNeedle);
    
  %  figure; imshow(leftImgNeedle_center);
  %  figure; imshow(rightImgNeedle_center);
     
    % Find the needle center locations
    [leftCenters_row, leftCenters_col] = find (leftImgNeedle_connected> 0);
    [rightCenters_row, rightCenters_col] = find (rightImgNeedle_connected> 0);
       
    
    [lr,li] = sort(leftCenters_row,1,'descend');
    leftCenters = [lr,leftCenters_col(li)]';
    
    [rr,ri] = sort(rightCenters_row,1,'descend');
    rightCenters = [rr,rightCenters_col(ri)]';

    
end