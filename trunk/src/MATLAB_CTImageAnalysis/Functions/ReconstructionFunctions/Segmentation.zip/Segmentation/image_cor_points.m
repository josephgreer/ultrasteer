function value = image_cor_points (input, sense, diff_image, insertion_point, tip_point, x0n)
% Author: Tom Wedlick
% Determines the curve correlation while also including input point
% variations

% Parse the input
%radius, arc_length
radius = input(1);
arc_length = input(2);
delta_insertion = real(input (3));
delta_tip = real(input(4));
%delta_tip_par = real(input(5));
delta_tip_par = 0;

%% Determine what the new insertion point
%  and tip points will be using the offset

insertion_point = determine_new_point (insertion_point, x0n, delta_insertion, 0);
tip_point = determine_new_point (tip_point, x0n, delta_tip, delta_tip_par);

%[insertion_point, tip_point]
%% Create the curve image
blank_image = diff_image * 0;

% gen_image = create_needle_image(...
%     insertion_point, radius, arc_length, sense,...
%     blank_image);

% Generare the circle image
[gen_image, x0n] = create_needle_image_2(...
    insertion_point, radius, arc_length, sense,...
    blank_image,tip_point);

% Spread out the circle image
ker = fspecial('disk', 1);
gen_image = (conv2(gen_image, ker, 'same') > 0);

% Determine the correpsondance;
cor_image = gen_image .* diff_image;

% Find how many pixels are in the generated image
[row, col, v] = find(gen_image == 1);

value = sum(sum(cor_image)) / (size(row,1));

% Return the correspondance value to be minimized
value = - value;

%% 
% figure(5)
% imshow(2*cor_image .* diff_image,[])
% imshow(2*cor_image + diff_image,[])
% hold on 
% plot(tip_point(1), tip_point(2), 'yo')
% hold off
% pause(.01);
% 

