function [imgOut,max_val,min_val] = scalePixels(img, imgMask, max_val, min_val)
%Input:
% An image
% A mask of the image (things outside of the mask inthe image will not be
% considered)
% Max value (optional)
% Min Value (optional)

%Output:
% Scaled image out
% Max pixel value out
% Min pixel value out
%
%Author: Tom Wedlick
if nargin<4 | isempty(max_val) | isempty(min_val), max_val=0; end

if (max(max(img)) - min(min(img))== 0)
    imgOut = 0*img;
    max_val = 0;
    min_val = 0;
else


    working_section = img .*imgMask;
    %imshow(working_section,[])

    if max_val <= 0
       %Determine the max and the min  
        %Find the maximum value
        max_val = max(max(working_section));

        %Find the minimum value in that window
        min_val = min(min(working_section + max_val*(imgMask==0)));

    end

    % Use the max and min values to rescale the pixel values to be between
    % 0 and 1
    working_section2 = (working_section - min_val *imgMask);
    working_section3 = working_section2/(max_val - min_val);

    imgOut = working_section3;

    %imshow(working_section3)
end