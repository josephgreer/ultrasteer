function output = gD (n)

output = quad(@sigf,n-0.5,n+0.5);