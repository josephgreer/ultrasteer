function [gen_image, x0n] = create_needle_image_2(...
    insertion_point, radius, arc_length, sense,...
    blank_image, tip)
% Author: Tom Wedlick
% Generares a portion of a circle between the specificed points

%% A script that generates a circular arc in an image
% 
% insertion_point = [80, 200]; %The point in the image where the needle starts
% radius = 800; %radius in pixels
% radius = 200; %radius in pixels
% arc_length = 500; %Arc-length in pixels
% sense = -1; %sense = 1 if needle bends up, -1 otherwise
% sense = 1;
% blank_image = zeros(600,800); %blank image used for sizing

%% Parse the Input
%bounds.x = insertion_point(1);
%bounds.y = insertion_point(2);
 
rn = radius;
x0n = [insertion_point(1),insertion_point(2) - radius* sense] ;

chord = norm(insertion_point - tip); %Ensure that the radius is large enough

% Determine the arc_length
arc_length = calc_arc_length (insertion_point, tip, rn);


%% Determine the center of the circle created with the perscribed radius
% and connecting the tip and needle base locations
% ref: http://mathworld.wolfram.com/Circle-CircleIntersection.html

x1 = chord / 2;
y1 = -(sense)*sqrt(rn ^2 - 0.25 * chord^2); % assume negative y1 since single bend insertion

v1 = tip - insertion_point; v1 = v1 / norm(v1);
v2 = [-v1(2) v1(1)];

x0n = insertion_point + x1 * v1 + y1 * v2;


%% Generate the points

plane_vect1 =[1;0];
plane_vect2 = [0;1] * sense;

circ_points = [];
theta_end = arc_length / radius;
arc_step = 1;

delta = insertion_point - x0n;

theta_start = atan2(real(delta(2)),real(delta(1)));
%theta_start * 180 / pi

for theta_step = 0: -(sense)*arc_step*abs(1 / rn) : -(sense)*theta_end
    theta = (sense)*theta_start + (sense)*theta_step;
    if theta_step == 0
        %circ_points = [x0n' + rn*plane_vect2*cos(theta) + rn*plane_vect1*sin(theta)];
        circ_points = [x0n' + rn*plane_vect1*cos(theta) + rn*plane_vect2*sin(theta)];
    else
        %circ_points = [circ_points, x0n' + rn*plane_vect2*cos(theta) + rn*plane_vect1*sin(theta)];
        circ_points = [circ_points, x0n' + rn*plane_vect1*cos(theta) + rn*plane_vect2*sin(theta)];
    end
    
end


% %%
% figure(6)
% hold off
% imshow(blank_image,[])
% hold on 
% plot(x0n(1), x0n(2), 'rx')
% hold on 
% plot(circ_points(1,:), circ_points(2,:))
% axis square
% hold on
% plot([insertion_point(1), tip(1)],[insertion_point(2), tip(2)],'y--o')
% hold on 
% axis equal





%% Generate needle image

image = blank_image;
circ_points = round(circ_points);
[i,j] = size(image);
for t = 1 : size(circ_points,2)
    x = circ_points(1,t);
    y = circ_points(2,t);
    x = real(x);
    y = real(y);
    if (x <= j && y <= i && x > 0 && y > 0)
        image(y,x) = 1;
    end
end


gen_image = image;



% % %imshow(image,[])
% imshow(image,[])
% axis equal
