function image_out = differentiateImage(image_in, dx, dy)

imagex = conv2(image_in, dx, 'same');

imagey = conv2(image_in, dy, 'same');

image_out = sqrt(imagex.^2 + imagey.^2);

