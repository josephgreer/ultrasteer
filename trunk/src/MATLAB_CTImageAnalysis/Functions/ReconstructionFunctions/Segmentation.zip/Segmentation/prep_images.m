% Script that opens needle images and then performs image processing on
% them.
% Author: Tom Wedlick
thresholds = [0.58;0.65;0.62];
thresholds = [0.6;0.65;0.62];
thresholds = [0.50;0.50;0.5];
thresholds = [0.50;0.45;0.70]; % for beta = 15

needle_width =[6;5;15];

for n = 1 : cam_num
%%    
    % Save previous Image
    cam(n).img_last = cam(n).img;
    
    % Read in the new image
    filename = cam(n).picts(loop+1).name;
    img_in = imread([folder filename],'ppm');
    cam(n).img = (double(img_in(:,:,1))+double(img_in(:,:,2))+double(img_in(:,:,3)))/3.0;
    cam(n).img = scalePixels(cam(n).img,ones(size(cam(n).img))); 

    % Create motion images
    cam(n).img_motion = cam(n).img - cam(n).background_in;
    cam(n).img_motion = cam(n).background_in - cam(n).img;
   
    
    % Scale the motion image to be from 0 to 1
    [cam(n).img_motion, max_val, min_val] = scalePixels(cam(n).img_motion .*cam(n).needle_Mask ,cam(n).needle_Mask);
    %imshow(cam(n).img_motion,[]);
        
    %Determine the gel motion
    cam(n).gel_motion = (cam(n).background_in - cam(n).img ).*cam(n).gel_Mask;
    cam(n).gel_motion = scalePixels(cam(n).gel_motion,cam(n).gel_Mask, max_val, min_val);
    %imshow(cam(n).gel_motion,[])

%    if (loop > 0 | max(max(cam(n).img_motion)) ~= 0)
if ( max(max(cam(n).img_motion)) ~= 0)
        % Segment out the needle "centers" (newer method, not as good)
        %cam(n).img_centers = segNeedle(cam(n).img_motion, cam(n).needle_Mask, cam(n).gel_Mask,needle_width(n));
  
        % segment out the needle
         cam(n).img_needle = segmentNeedle2(cam(n).img_motion,...
                                 cam(n).needle_Mask, cam(n).gel_motion,...
                                 cam(n).gel_Mask, thresholds(n));
                             
%        cam(n).img_needle = segmentNeedle2(cam(n).img .*cam(n).needle_Mask,...
%                                cam(n).needle_Mask, cam(n).background_masked,...
%                                cam(n).gel_Mask, cam(n).gel_motion);
                            

        %Just use the new method for the center points until I can get the center
        %points code working again. 
        [row,col,val] = find(cam(n).img_needle> 0.05);
        if (length(val) < 10)
            cam(n).isMotion = false;
            disp(['No Motion detected in ', cam(n).name , ' camera.']);
        else
            cam(n).isMotion = true;
        end

        %Ensure that the image centers are on the needle
        %cam(n).img_centers = (cam(n).img_centers .* cam(n).img_needle > 0);

        % Implement the old code to determine the needle center points
        [cam(n).img_centers_improved] = needle_points2( cam(n).img_motion, 2, .8, cam(n).isMotion, cam(n).needle_Mask, cam(n).img_needle);
        
        % Rescale the pixel values from the improved center line finder
        % and then threshold
        temp_pic = scalePixels(cam(n).img_centers_improved,(cam(n).img_needle > 0));
        cam(n).img_centers_improved = temp_pic .* (temp_pic > 0.2);
        
        % Find the needle point locations
        [ cam(n).img_needle_row, cam(n).img_needle_col ] = find ( cam(n).img_needle > 0);
        
        
        % Find the needle center locations
        [ cam(n).img_centers_row, cam(n).img_centers_col ] = find ( cam(n).img_centers_improved > 0);
        
        if (isGraphicsOn)
            figure(n)
            subplot(2,2,1)
                imshow(cam(n).img,[])
            subplot(2,2,2)
                imshow(cam(n).img_needle,[])
            subplot(2,2,3)
                imshow(cam(n).img_centers_improved>0,[])
           subplot(2,2,4) 
            %imshow(cam(n).img_centers_improved,[])
            imshow(-(cam(n).img_centers_improved>0)+(cam(n).img_needle>0),[])

            figure(n+4)
              imshow(cam(n).img+3*(cam(n).img_centers_improved>0) + cam(n).img_needle,[]);
        end
                    
    end
%%
end