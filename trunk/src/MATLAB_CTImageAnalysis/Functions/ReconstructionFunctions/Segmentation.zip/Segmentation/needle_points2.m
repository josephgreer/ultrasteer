function [imageOut] = needle_points2 (image_in, needle_width, sigma, isMotion, needleMask, segNeedleImg )
% Returns the pixels along the center line of the needle


%% Read in the image
% clear all
% close all 
% 
% 
% image = background - image_in; %remove background
% 
% %imshow (image_in,[])
% imageOut = image_in;
% motion = false;
% 
% image = double(image .* double(image > 10)); %cull small noise pixels
% if (max(max(image)) > 0)
%     image = (255 / max(max(image)))*image; %rescale the image values
%     %imshow (image, []);
%     
%     % Normalize the image
%     gel_thresh = (255 / max(max(image)))*gel_thresh;
% end

image = image_in;
imageOut = image;

% Determine whether there is motion
if(~isMotion)
    %'No motion detected'
    motion = false;
else
    motion = true; 
    %disp('Motion Detected')

%% Set up the parameters

%w = 1;
w = needle_width/2;

%sigma = 0.8;
 if (sigma < w / sqrt(3))
     sigma = w / sqrt(3);
 end

 %% Form the gaussian kernel
 epsilon = 10^-4;
 

t = 0;
gpkerD = gpD(t);
gpkerD_left = []; 

while (gD(t) > epsilon/2)
           t = t + 1;
           gpkerD_left = [gpkerD_left gpD(t)];
end

gpkerD = [-gpkerD_left(t:-1:1) gpkerD gpkerD_left];

gkerD = fspecial ('gaussian', size(gpkerD));

% Note that if t < 5 * sigma, then you do not have an acceptable kernel
%5 * sigma;
%t;

%% Smooth the image
result = conv2(conv2 (image, gkerD, 'same'), gkerD', 'same');
result = scalePixels(result,ones(size(result)));

 figure(40)
 imshow(result,[])

%% Differentiate the image twice
imageD = differentiateImage(result,gpkerD, gpkerD');
imageDD = differentiateImage(imageD,gpkerD, gpkerD');%.*(imageDD > 5)

se = strel('disk',5);

imageD = imageD .* imerode(needleMask,se);
imageDD = imageDD .* imerode(needleMask,se);

%imageD = scalePixels(imageD,ones(size(imageD)));
%imageDD = scalePixels(imageDD,ones(size(imageD)));

imageD = scalePixels(imageD,needleMask);
imageDD = scalePixels(imageDD,needleMask);

imageD = scalePixels(imageD,imdilate(segNeedleImg,se));
imageDD = scalePixels(imageDD,imdilate(segNeedleImg,se));

%imshow(imageD<0.1,[])
%figure; imshow(imageDD,[])

%imshow(imageDD<0.5,[])

 figure(42)
 imshow(imageD,[])
 figure(41)
 imshow(imageDD,[])
%possible_points = image.*double((result > 20).*(imageD < 40));
%imshow(possible_points,[])
%possible_points = image.*double(result.*(imageD < 10));

possible_points = image.*double(scalePixels(-result,needleMask) .*(imageD < 0.25) .* (imageDD<0.4)); % TRY TO CHANGE THESE VALUES TO SEE IF HELPS

%Ensure that the needle center points are on the needle
possible_points = possible_points .*(possible_points.*segNeedleImg>0);
%figure; imshow(possible_points,[])

% Return the center points
imageOut = possible_points;

% %Needle pixels should be within 5 pixels of another needle pixel
% ker = ones(9,9); ker(5,5) = 0;
% imageOut = imageOut .* double(conv2(imageOut, ker, 'same')>0);

end 

%% New Code to try to improve the result
% 
% if(isMotion)
%       needle_image3 = possible_points; 
%     %     % Open the image with an erosion and then a dialation
%     %     se = strel('disk',1);
%     %     needle_image3 = imopen(needle_image3,se);
%     %     %imshow(needle_image2)
% 
%     se = strel('disk',15);
%     needle_image3 = imclose(needle_image3,se);
%     %figure, imshow(closeBW,[])
% 
%         %Skeletonize the needle
%         needle_image4 = bwmorph(needle_image3,'skel',Inf);
%         %imshow(needle_image4,[])
% 
% 
%         imageOut = needle_image4;
% end