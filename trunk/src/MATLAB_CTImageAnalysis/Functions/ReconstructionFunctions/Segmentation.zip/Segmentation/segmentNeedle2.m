%function segNeedle = segmentNeedle2(image_in, needle_Mask, background, gel_Mask, gel_sample_in)


function segNeedle = segmentNeedle2(motion_in, needle_Mask, gel_motion, gel_Mask, optionalThresh)
   
%Input:
% image of the needle
% Mask of the needle "area"
% image of the background
% Mask of the gel (where the needle will not be)
% Sample of gel motion ((image-background ) .* gel_Mask;)

%Output
% Image of the segmented needle
% Author: Tom Wedlick

% 
% %imshow (background,[])
% %imshow (image_in,[])
% imshow(gel_sample_in,[]);
%   
% % Perform background subtraction
% image = (background - image_in); 
% image = image .* (image >0);%Enforce that we only want positive pixel changes. 
% [image,max_val, min_val] = scalePixels(image,needle_Mask);
% imshow(image,[])
% 
% [max_val, min_val]
% 
% %image = image .* (image >0);
% %imshow(image)
% 
% % if ( (max(max(gel_sample_in)) < 0) || abs(min(min(gel_sample_in))) > 2* abs(max(max(gel_sample_in)) < 0) )
% %     gel_sample_in = -gel_sample_in; 
% %     disp('invert gel sample in ');
% % end
% 
% 
% gel_sample = gel_sample_in .* (gel_sample_in>0);
% gel_sample = scalePixels(gel_sample,gel_Mask, max_val, min_val);
% imshow(gel_sample,[])

image = motion_in;
gel_sample = gel_motion;

% Find the user specified gel locations
gel_index = find (gel_Mask == 1);

%imshow(gel_sample)
gel_mean = mean(gel_sample(gel_index));
gel_stdDev = std(gel_sample(gel_index));


% Average pixel values to help eliminate noise
ker = fspecial('disk', 3);
image = conv2(image, ker, 'same');



% Only consider the selected region of the gel
image = needle_Mask .* image;

%temp = needle_Mask .* image


%imshow (temp .* (temp >= 0),[])



% Theshold the needle
threshold = (gel_mean + 20 * gel_stdDev);

if ~isempty(optionalThresh)
    threshold = optionalThresh;
end

%figure(200);
%imshow(image,[]);

image = image .* (image > threshold);

% %Needle pixels should be within 3 pixels of another needle pixel
 ker = ones(9,9); ker(3,3) = 0;
 image = image .* double(conv2(image, ker, 'same')>0);

segNeedle = image; 
%imshow(segNeedle,[]) 