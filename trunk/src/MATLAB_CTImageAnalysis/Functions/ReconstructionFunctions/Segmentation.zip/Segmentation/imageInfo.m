  function [needle_Mask, background, gel_Mask, gel_thresh, poly_out, gel ] = imageInfo (image, background)

    imshow (image,[])
    % Have the user select a region that will have the needle in it. 
    [needle_Mask, xi, yi]  = roipoly;
    background = background .* double(needle_Mask);
    
    

    imshow (image,[])
    % HAve the user select a region that represents the gel (no needle)
    gel_Mask = needle_Mask; %gel_Mask = double (roipoly );
    
    gel = (image-background ) .* gel_Mask;
    gel_thresh = mean(mean(image(find(gel == 1)))); 
    
    poly_out = [xi,yi];
    
    %gel = image .* gel_Mask;
    
    
%     
%     function [SegNeedleImg, poly_out] = imageInfo (image, background)
% 
% %[needle_Mask, background, gel_Mask, gel_thresh, poly_out, gel ] = imageInfo (image, background)
%     imshow (image,[])
%     % Have the user select a region that will have the needle in it. 
%     [needle_Mask, xi, yi]  = roipoly;
%    
%     background = background .* double(needle_Mask);
%     needleMasked = image.*needle_Mask;
%     
%     SegNeedleImg = background - needleMasked;
% 
%    % imshow (image,[])
%     % HAve the user select a region that represents the gel (no needle)
%    
%    % gel_Mask = needle_Mask; %gel_Mask = double (roipoly );
%     
%   %  gel = (image-background ) .* gel_Mask;
%   %  gel_thresh = mean(mean(image(find(gel == 1)))); 
%     
%     poly_out = [xi,yi];
%     
%     %gel = image .* gel_Mask;