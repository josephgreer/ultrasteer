function [needle_connected] = connectedComponents(needle_segmented)

CC = bwconncomp(needle_segmented,4);
       
%figure; imshow(label2rgb(labelmatrix(CC)));

needle_connected = zeros(size(needle_segmented));

if CC.NumObjects == 1
    needle_connected = needle_segmented;
else
    eccentricity = regionprops(CC,'Eccentricity');
    orientation = regionprops(CC,'Orientation');
    for i=1:CC.NumObjects
        if eccentricity(i,1).Eccentricity > 0.7
            if orientation(i,1).Orientation < 80
                needle_connected(CC.PixelIdxList{1,i}) = 1;
            end
        end
    end

end

%figure; imshow(needle_connected);
